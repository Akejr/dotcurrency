import React, { useState } from 'react';
import { ChevronDown } from 'lucide-react';

interface Country {
  name: string;
  code: string;
  currency: string;
}

interface ExchangeRates {
  [key: string]: number;
}

function App() {
  const [sendAmount, setSendAmount] = useState('250000.00');
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [adminPassword, setAdminPassword] = useState('');
  const [exchangeRates, setExchangeRates] = useState<ExchangeRates>({
    BRL: 215,
    EUR: 920,
    AED: 235,
    CNY: 130,
    GBP: 1050,
    USD: 830,
    CAD: 615
  });
  const [tempRates, setTempRates] = useState<ExchangeRates>({...exchangeRates});
  
  const [selectedCountry, setSelectedCountry] = useState<Country>({
    name: 'Brasil',
    code: 'br',
    currency: 'BRL'
  });

  const countries: Country[] = [
    { name: 'Brasil', code: 'br', currency: 'BRL' },
    { name: 'Portugal', code: 'pt', currency: 'EUR' },
    { name: 'Emirados Árabes', code: 'ae', currency: 'AED' },
    { name: 'China', code: 'cn', currency: 'CNY' },
    { name: 'Reino Unido', code: 'gb', currency: 'GBP' },
    { name: 'União Europeia', code: 'eu', currency: 'EUR' },
    { name: 'Estados Unidos', code: 'us', currency: 'USD' },
    { name: 'Canadá', code: 'ca', currency: 'CAD' }
  ];

  const formatNumber = (value: string) => {
    let numericValue = value.replace(/[^\d]/g, '');
    const number = parseInt(numericValue || '0') / 100;
    return new Intl.NumberFormat('pt-BR', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(number);
  };

  const handleSendAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const rawValue = e.target.value.replace(/[^\d]/g, '');
    setSendAmount(rawValue || '0');
  };

  const calculateReceiveAmount = () => {
    const numericSendAmount = parseInt(sendAmount.replace(/[^\d]/g, '')) / 100;
    const rate = exchangeRates[selectedCountry.currency] || 1;
    const receiveAmount = numericSendAmount / rate;
    return receiveAmount.toFixed(2);
  };

  const handleRateChange = (currency: string, value: string) => {
    const numericValue = value.replace(/[^\d.]/g, '');
    setTempRates(prev => ({
      ...prev,
      [currency]: parseFloat(numericValue) || 0
    }));
  };

  const handleSaveRates = () => {
    setExchangeRates({...tempRates});
    setIsAuthenticated(false);
    setIsAdminOpen(false);
  };

  const handleAdminAuth = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminPassword === 'Evandro1@') {
      setIsAuthenticated(true);
      setAdminPassword('');
    } else {
      alert('Senha incorreta');
      setAdminPassword('');
    }
  };

  return (
    <div 
      className="min-h-screen flex items-center justify-center p-4 sm:p-6 md:p-8"
      style={{
        background: 'linear-gradient(180deg, #000033 0%, #000066 100%)'
      }}
    >
      <div className="bg-white rounded-3xl p-4 sm:p-6 md:p-8 w-full max-w-sm mx-auto">
        {/* Logo */}
        <div className="flex justify-center mb-8">
          <img 
            src="https://i.imgur.com/vqKHcgZ.png" 
            alt="DOT Logo" 
            className="w-24 sm:w-28 md:w-32 h-auto"
          />
        </div>

        {/* Send Amount Section */}
        <div className="mb-4 sm:mb-6">
          <p className="text-gray-600 mb-2 text-sm">Você envia exatamente</p>
          <div className="bg-white rounded-xl sm:rounded-2xl p-3 sm:p-4 shadow-lg border border-gray-100">
            <div className="flex justify-between items-center">
              <input
                type="text"
                value={formatNumber(sendAmount)}
                onChange={handleSendAmountChange}
                className="text-xl sm:text-2xl font-semibold w-32 sm:w-40 focus:outline-none"
                inputMode="decimal"
              />
              <div className="flex items-center gap-2 sm:gap-3 bg-gray-50 px-2 sm:px-3 py-1.5 rounded-lg">
                <div className="flex items-center gap-2">
                  <img 
                    src="https://flagcdn.com/w40/ao.png" 
                    alt="Angola" 
                    className="w-5 h-5 rounded-full object-cover"
                  />
                  <span className="font-medium text-sm">AOA</span>
                </div>
                <ChevronDown className="w-4 h-4 text-gray-400" />
              </div>
            </div>
          </div>
        </div>

        {/* Receive Amount Section */}
        <div className="mb-8">
          <p className="text-gray-600 mb-2 text-sm">O beneficiário recebe</p>
          <div className="bg-white rounded-xl sm:rounded-2xl p-3 sm:p-4 shadow-lg border border-gray-100">
            <div className="flex justify-between items-center">
              <input
                type="text"
                value={formatNumber(calculateReceiveAmount())}
                readOnly
                className="text-xl sm:text-2xl font-semibold w-32 sm:w-40 focus:outline-none"
                inputMode="decimal"
              />
              <div className="relative">
                <button
                  onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                  className="flex items-center gap-2 sm:gap-3 bg-gray-50 px-2 sm:px-3 py-1.5 rounded-lg focus:outline-none"
                >
                  <div className="flex items-center gap-2">
                    <img 
                      src={`https://flagcdn.com/w40/${selectedCountry.code}.png`}
                      alt={selectedCountry.name}
                      className="w-5 h-5 rounded-full object-cover"
                    />
                    <span className="font-medium text-sm">{selectedCountry.currency}</span>
                  </div>
                  <ChevronDown className="w-4 h-4 text-gray-400" />
                </button>

                {/* Dropdown Menu */}
                {isDropdownOpen && (
                  <div className="absolute right-0 bottom-full mb-2 w-44 sm:w-48 bg-white rounded-xl shadow-lg border border-gray-100 py-2 z-10">
                    {countries.map((country) => (
                      <button
                        key={country.code}
                        className="w-full px-3 sm:px-4 py-2 text-left hover:bg-gray-50 flex items-center gap-2"
                        onClick={() => {
                          setSelectedCountry(country);
                          setIsDropdownOpen(false);
                        }}
                      >
                        <img 
                          src={`https://flagcdn.com/w40/${country.code}.png`}
                          alt={country.name}
                          className="w-5 h-5 rounded-full object-cover"
                        />
                        <span className="text-sm">{country.name}</span>
                        <span className="ml-auto font-medium text-sm">{country.currency}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Send Button */}
        <button className="w-full bg-[#000033] text-white py-3 sm:py-4 rounded-xl font-semibold hover:bg-[#000044] transition-colors text-sm sm:text-base mb-4">
          ENVIAR
        </button>

        {/* Admin Section Toggle */}
        <button
          onClick={() => setIsAdminOpen(!isAdminOpen)}
          className="w-full text-center text-sm text-gray-500 hover:text-gray-700 mb-2"
        >
          Administrador
        </button>

        {/* Admin Section */}
        {isAdminOpen && !isAuthenticated && (
          <div className="border-t pt-4 mt-4">
            <form onSubmit={handleAdminAuth} className="space-y-3">
              <div>
                <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
                  Senha do Administrador
                </label>
                <input
                  type="password"
                  id="password"
                  value={adminPassword}
                  onChange={(e) => setAdminPassword(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500"
                  placeholder="Digite a senha"
                />
              </div>
              <button
                type="submit"
                className="w-full bg-[#000033] text-white py-2 rounded-lg text-sm font-medium hover:bg-[#000044] transition-colors"
              >
                Acessar
              </button>
            </form>
          </div>
        )}

        {/* Admin Exchange Rates Section */}
        {isAdminOpen && isAuthenticated && (
          <div className="border-t pt-4 mt-4">
            <div className="flex justify-between items-center mb-3">
              <h3 className="text-sm font-semibold text-gray-700">Configurar Taxas de Câmbio (1 moeda = X AOA)</h3>
              <button
                onClick={() => {
                  setIsAuthenticated(false);
                  setIsAdminOpen(false);
                }}
                className="text-sm text-red-600 hover:text-red-700"
              >
                Sair
              </button>
            </div>
            <div className="space-y-3">
              {countries.map((country) => (
                <div key={country.code} className="flex items-center gap-3">
                  <div className="flex items-center gap-2 w-24">
                    <img 
                      src={`https://flagcdn.com/w40/${country.code}.png`}
                      alt={country.name}
                      className="w-5 h-5 rounded-full object-cover"
                    />
                    <span className="text-sm font-medium">{country.currency}</span>
                  </div>
                  <input
                    type="text"
                    value={tempRates[country.currency]}
                    onChange={(e) => handleRateChange(country.currency, e.target.value)}
                    className="flex-1 px-3 py-1.5 text-sm border rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500"
                    placeholder="Taxa de câmbio"
                  />
                </div>
              ))}
              <button
                onClick={handleSaveRates}
                className="w-full bg-green-600 text-white py-2 rounded-lg text-sm font-medium hover:bg-green-700 transition-colors mt-4"
              >
                Salvar Taxas
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;